// conf.js
exports.config = {
  seleniumAddress: 'http://localhost:4444/wd/hub',
  specs: ['addUser.js']
    //,
    //capabilities: {
    //    browserName: 'firefox'
    //}
}