// spec.js
describe('Protractor Demo App', function() {
    beforeEach(function() {
        browser.ignoreSynchronization = true;
        browser.get('http://localhost:2000');
    });
    function add(fristName, lastName,email,userName,verifyPassword,password_input) {
        element(by.partialLinkText("Create User")).click();
        element(by.id('title')).sendKeys('cteachera');
        element(by.name('firstName')).sendKeys('cteachera');
        element(by.name('lastName')).sendKeys('cteachera');
        element(by.name('email')).sendKeys('982361920@qq.com');
        element(by.name('userName')).sendKeys(userName);

        element(by.name('verifyPassword')).sendKeys('cteachera');
        element(by.name('password_input')).sendKeys('cteachera');
        element(by.name('bottom_Submit')).click();
        browser.sleep(3000);
    }
    it('should add one and two', function() {
        element(by.id('user_id')).sendKeys('administrator');
        element(by.id('password')).sendKeys('changeme');

        element(by.id('entry-login')).click();
        browser.sleep(3000);

        element.all(by.css('.link-text.ng-scope.ng-binding')).get(7).click();
        browser.sleep(1000);

        browser.switchTo().frame(browser.findElement(by.tagName('iframe')));
        //element(by.css('.portletList a')).click();
        //element(by.cssContainingText('.collapsible', 'Users')).click();
         element(by.id("nav_list_users")).click();
        add('Blackboard','cteachera','982361920@qq.com','cteacher','cteachera','cteachera');
        add('Blackboard','cteacherb','982361920@qq.com','cteacherd','cteacherb','cteacherb');
        add('Blackboard','cstua','982361920@qq.com','cstua','cstu','cstua');
        add('Blackboard','cstub','982361920@qq.com','cstub','cstud','cstub');




        browser.getAllWindowHandles().then(function (handles) {
            browser.switchTo().window(handles[0]);
        });
    });
});

