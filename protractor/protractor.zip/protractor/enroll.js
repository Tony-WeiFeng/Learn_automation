/**
 * Created by cjin on 4/12/15.
 */
describe('Protractor Demo App', function() {

    beforeEach(function() {
        browser.ignoreSynchronization = true;

        browser.get('http://localhost:2000');
    });
    it('should add one and two', function() {
        element(by.id('user_id')).sendKeys('administrator');
        element(by.id('password')).sendKeys('changeme');

        element(by.id('entry-login')).click();
        browser.sleep(3000);

        element.all(by.css('.link-text.ng-scope.ng-binding')).get(7).click();
        browser.sleep(2000);

        browser.switchTo().frame(browser.findElement(by.tagName('iframe')));
        element(by.id('nav_list_courses')).click();

        element(by.id('courseInfoSearchText')).sendKeys('Java');
        element(by.css('.button-4')).click();
        element(by.partialLinkText("J00001")).click();
        browser.sleep(2000);


        element(by.css('.modal-footer-button.success.ng-scope')).click();
        browser.getAllWindowHandles().then(function (handles) {
            browser.switchTo().window(handles[0]);
        });
    });
});

